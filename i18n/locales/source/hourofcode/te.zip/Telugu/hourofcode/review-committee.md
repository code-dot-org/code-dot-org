---
title: Hour of Code and CSEdWeek Review Committee
---

# Hour of Code and CSEdWeek Review Committee

<%= view :about_headshots, people:DB[:cdo_team].where(kind_s:'hoc_review') %>

<%= view :about_people, people:DB[:cdo_team].where(kind_s:'hoc_review_short') %>