---
title: Whole School Participation
layout: wide
---

{{ signup_button }}

# Get your whole school to participate

Information about getting whole schools to participate in the Hour of Code will go here.