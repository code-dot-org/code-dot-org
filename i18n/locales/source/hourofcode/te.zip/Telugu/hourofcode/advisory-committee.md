---
title: Hour of Code and CSEdWeek Advisory Committee
---

# Hour of Code and CSEdWeek Advisory Committee

{{ advisory-committee/about_headshots }}

{{ advisory-committee/about_people }}