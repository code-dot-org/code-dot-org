---
title: Past Hour of Code Posters
layout: wide
nav: promote_nav
---

{{ signup_button }}

# Past Hour of Code Posters

### Find our posters from previous years to print and hang in your classroom! Looking for the newest posters? [Click here]({{ promote/promote_posters_url }}).

* * *

<br />

{{ promote_posters }}

{{ signup_button }}