Standalone karel project
